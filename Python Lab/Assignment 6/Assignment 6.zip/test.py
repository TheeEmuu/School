import analyze

a = (1, 2, 5, 4, 8, 9, 7, 6, 3)

print(analyze.minimum(a))
print(analyze.maximum(a))
print(analyze.k_largest(a, 3))
print(analyze.median(a))
print(analyze.average(a))
print(analyze.standard_deviation(a))
